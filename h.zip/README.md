# hn-posts-copy

**This is currently a beta due to front-end imperfection.**

Adds checkboxes next to each post on https://hckrnews.com/, copies selected checkboxes to clipboard.

## TODO

- Align each checkbox with post (I am no front-end guy :( PRs are welcomed.).